#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <assert.h>
#include "spkmeans.h"
#define BUFSIZE 10000

int main(int argc, char *argv[])
{
    FILE *fp;
    double **points_arr,n1;
    int d,N,i,j,K;
    char *g,*s,buff[BUFSIZE];
    char c1;
    enum goal y;
    i = 0, j = 0,K,d=10,N=50;
    n1=0;
    points_arr = (double **) initpointArray(N, N);
    if (argc != 4) {
        printf("Invalid Input!");
        return 0;
    }
    K = atoi(argv[1]);
    g = argv[2];
    fp = fopen(argv[3], "r");
    if(fp==NULL){
    printf("An Error Has Occurred");
    return 0;
    }

    if (fgets(buff, BUFSIZE - 1, fp) == NULL) {
        printf("An Error Has Occurred");
        return 0;
    }
    s = buff;
    i = 0;
    while ((sscanf(s, "%lf%c%s", &n1, &c1, s) == 3) && (c1 != '\n')) {
        points_arr[j][i] = n1;
        i++;
    }
    points_arr[j][i] = n1;
    j++;
    d=i+1;
    while (fgets(buff, BUFSIZE - 1, fp) != NULL) {
        s = buff;
        i = 0;
        while ((sscanf(s, "%lf%c%s", &n1, &c1, s) == 3) && (c1 != '\n')) {
            points_arr[j][i] = n1;
            i++;
        }
        points_arr[j][i] = n1;
        j++;
    }
    if(j>d)
        N = j;
    else
        N=d;
    fclose(fp);
    if (K > N || K < 0) {
        printf("Invalid Input!");
        return 0;
    }
    if (strcmp(g,"wam") == 0) {
        y = wam;
        PrintWeightMat(points_arr,N,d);
    }

    if (strcmp(g, "ddg") == 0) {
        y = ddg;
        PrintDiagonalMat(points_arr,N,d);
    }
    if (strcmp(g, "lnorm") == 0) {
        y=lnorm;
        PrintLaplacian(points_arr,N,d);
    }

    if (strcmp(g, "spk") == 0) {
        y=spk;
        PrintKmeans(points_arr,N,d,K);
    }

    if (strcmp(g, "jacobi") == 0) {
        y=jacobi;
        PrintJacobi(points_arr,N,d);
    }
    if(y!=(wam||ddg||jacobi||lnorm||spk))
        printf("Invalid Input!");
    return 0;
}

void PrintWeightMat(double **points_arr,int n,int d)
{
    double **W;
    W = (GenWeightMat(points_arr, n,d));
    printMat(W, n,n);
    freeMemoryArray(W,n);
    freeMemoryArray(points_arr,n);


}
void PrintDiagonalMat(double **points_arr,int n,int d)
{
    double **W,**D;
    W = GenWeightMat(points_arr,n,d);
    D = GenDiagonalMat(W,n);
    printMat(D, n,n);
    freeMemoryArray(W,n);
    freeMemoryArray(D,n);
    freeMemoryArray(points_arr,n);

}
void PrintLaplacian(double **points_arr,int n,int d)
{
    double **W,**D,**L;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W,n);
    L = GenLaplacian(W,D,n);
    printMat(L,n,n);
    freeMemoryArray(D,n);
    freeMemoryArray(W,n);
    freeMemoryArray(points_arr,n);

}

void PrintJacobi(double **points_arr,int n,int d)
{
    int r;
    double **W,**D,**L;
    double ***results;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W, n);
    L = GenLaplacian(W,D,n);
    results = GenJacobi(L,n);
    for (r = 0; r < n-1; r++)
    {
        printf("%.4f,", results[1][r][r]);
    }
    printf("%.4f\n", results[1][n-1][n-1]);
    printMat(results[0],n,n);
    freeMemoryArray(D,n);
    freeMemoryArray(W,n);
    freeMemoryMat(results,2,n);
    freeMemoryArray(points_arr,n);


}

void PrintKmeans(double **points_arr,int n,int d,int k)
{
    int t,l;
    double **W,**D,**L,**eigenVectors,**T;
    double ***results;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W, n);
    L = GenLaplacian(W,D,n);
    results = GenJacobi(L,n);
    results[0] = Transpose(results[0],n);
    if (k == 0)
       k = GenEigengap(results[0], results[1], n);
    eigenVectors = (double **) initpointArray(n, k);
    for (t = 0; t < k; ++t) {
        for (l = 0; l < n; ++l) {
            eigenVectors[l][t] = results[0][t][l];
        }
    }
    T = Renormalize(eigenVectors, n, k);
    kMeans(T,n,k);
    freeMemoryArray(D,n);
    freeMemoryArray(eigenVectors,n);
    freeMemoryArray(W,n);
    freeMemoryArray(T,n);
    freeMemoryMat(results,2,n);
    freeMemoryArray(points_arr,n);


}
void PrintRandMeans(double **points_arr,int *center_arr,int n,int d,int k)
{
    int t,l,i,j;
    double **W,**D,**L,**U,**T,**P;
    double ***results;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W, n);
    L = GenLaplacian(W,D,n);
    results = GenJacobi(L,n);
    results[0] = Transpose(results[0],n);
    GenEigengap(results[0], results[1], n);
    U = (double **) initpointArray(n, k);
    for (t = 0; t < k; ++t) {
        for (l = 0; l < n; ++l) {
            U[l][t] = results[0][t][l];
        }
    }
    T = Renormalize(U,n,k);
    P = initpointArray(n,k);
    P = copyMat(T,n,k);
    for(i=0;i<k;i++)
    {
        for(j=0;j<k;j++)
        {
            P[i][j] = T[center_arr[i]][j];
            P[center_arr[i]][j] = T[i][j];
        }

    }

    kMeans(P,n,k);
    freeMemoryArray(D,n);
    freeMemoryArray(W,n);
    freeMemoryArray(U,n);
    freeMemoryArray(T,n);
    freeMemoryArray(P,n);
    freeMemoryMat(results,2,n);
    freeMemoryArray(points_arr,n);
}


int Get_means(double **points_arr,int n,int d)
{

    double **W,**D,**L;
    int k=0;
    double ***results;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W, n);
    L = GenLaplacian(W,D,n);
    results = GenJacobi(L,n);
    results[0] = Transpose(results[0],n);
    k = GenEigengap(results[0], results[1], n);
    freeMemoryArray(D,n);
    freeMemoryArray(W,n);
    freeMemoryMat(results,2,n);
    freeMemoryArray(points_arr,n);
    return k;

}
double *Get_T(double **points_arr,int n,int d,int k)
{
    int t,l,r;
    double **W,**D,**L,**eigenVectors,**T;
    double *newObs;
    double ***results;
    W = GenWeightMat(points_arr, n,d);
    D = GenDiagonalMat(W, n);
    L = GenLaplacian(W,D,n);
    results = GenJacobi(L,n);
    results[0] = Transpose(results[0],n);
    GenEigengap(results[0], results[1], n);
    eigenVectors = (double **) initpointArray(n, k);
    for (t = 0; t < k; ++t) {
        for (l = 0; l < n; ++l) {
            eigenVectors[l][t] = results[0][t][l];
        }
    }
    T = Renormalize(eigenVectors, n, k);
    newObs = calloc(n*k, sizeof(double));
    if(newObs==NULL)
        {printf("An Error Has Occurred");
        exit(0);}
    r=0;
    for (t = 0; t < n; ++t) {
        for (l = 0; l < k; ++l) {
            newObs[r] = T[t][l];
            r++;
        }
    }

    freeMemoryArray(D,n);
    freeMemoryArray(eigenVectors,n);
    freeMemoryArray(W,n);
    freeMemoryArray(T,n);
    freeMemoryMat(results,2,n);
    freeMemoryArray(points_arr,n);

    return newObs;

}

double **initpointArray(int N, int d) {
    int i;
    double **obs = calloc(N, sizeof(double *));
    if(obs==NULL)
        {printf("An Error Has Occurred");
        exit(0);}
    for (i = 0; i < N; i++) {
        obs[i] = (double *) calloc(d, sizeof(double ));
        if(obs[i]==NULL)
           { printf("An Error Has Occurred");
            exit(0);}
    }
    return obs;
}

void printMat(double **A, int K, int d) {
    /*display output*/
    int k, j;
    for (k = 0; k < K; k++) {
        for (j = 0; j < d-1; j++) {
            if (j < d - 1) {
                if(A[k][j]>=-0.00004 && A[k][j]<0)
                    printf("%.4f,", -A[k][j]);
                else
                    printf("%.4f,", A[k][j]);

            } else {
                if(A[k][j]>=-0.00004 && A[k][j]<0)
                    printf("%.4f,", -A[k][j]);
                else
                    printf("%.4f,", A[k][j]);
            }
        }
        if(A[k][d-1]>=-0.00004 && A[k][d-1]<0)
            printf("%.4f", -A[k][d-1]);
        else
            printf("%.4f", A[k][d-1]);
        if(k!=K-1)
            printf("\n");
    }
}

void freeMemoryArray(double **arr, int size) {
    int i;
    for (i = 0; i < size; i++) {
        free(arr[i]);
    }

    free(arr);
}

double** GenWeightMat(double **points_arr,int n,int d){
    int i,j,k;
    double **W,result;
    W = (double **)initpointArray(n,n);
    result=0;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++)
        {
            if(i!=j)
            {
                for (k = 0; k < d; k++) {
                    result += pow(fabs(points_arr[i][k] - points_arr[j][k]),2);
                }
                result = exp(-(pow(result,0.5)/2));
            } else
                result=0;
            W[i][j] = result;
            result=0;
        }
    }
    return W;
}

double** GenDiagonalMat(double **points_arr,int n){
    int i,j;
    double ** D,result;
    D = (double **)initpointArray(n,n);
    result=0;
    for(i=0;i<n;i++)
    {
        result=0;
        for(j=0;j<n;j++)
        {
            result +=points_arr[i][j];
        }
        D[i][i] = result;
    }
    return D;
}

double ** multiplyMat(double **A,double **B,int n)
{
    int i,j,k;
    double **P;
    P = (double **)initpointArray(n,n);
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++) {
            for (k = 0; k < n; k++) {
                P[i][j] += A[i][k] * B[k][j];
            }
        }
    }
    return P;
}

double** GenLaplacian(double ** weightMat,double **diagonalMat,int n)
{
    int i,j;
    double **laplacianMat,**laplacianTemp;
    for(i=0;i<n;i++)
    {
        for(j=0;j<n;j++) {
            if(diagonalMat[i][j]!=0)
                diagonalMat[i][j] = pow(diagonalMat[i][j],-0.5);
        }
    }
    laplacianTemp = multiplyMat(diagonalMat,weightMat,n);
    laplacianMat = multiplyMat(laplacianTemp,diagonalMat,n);
    for (i = 0; i < n; ++i) {
        for(j=0;j<n;j++) {
            if(j==i)
                laplacianMat[i][i] = (1 - laplacianMat[i][i]);
            else
                laplacianMat[i][j] = -laplacianMat[i][j];
        }

    }

    freeMemoryArray(laplacianTemp,n);
    return laplacianMat;

}


double ** Transpose(double **P,int n)
{
    int i,j;
    double **Ptag;
    Ptag = (double **)initpointArray(n,n);
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++)
        {
            Ptag[i][j]=P[j][i];
            Ptag[j][i]=P[i][j];
        }
    }
    return Ptag;
}
double ** copyMat(double **P,int n,int d)
{
    int i,j;
    double **copy;
    copy = (double **)initpointArray(n,d);
    for(i=0;i<n;i++)
    {
        for(j=0;j<d;j++)
        {
            copy[i][j]=P[i][j];
        }
    }
    return copy;
}
double offMat(double **A,double **Atag,int n)
{
    int i,j;
    double AOffDia,AtagOffDia;
    AtagOffDia=0,AOffDia=0;
    for(i=0;i<n;i++)
    {
        for(j=i;j<n;j++)
        {
            if(i!=j)
            {
                AOffDia+= 2*pow(A[i][j],2);
                AtagOffDia+= 2*pow(Atag[i][j],2);
            }
        }
    }
    return ((AOffDia)-(AtagOffDia));
}

double ***initmatrixArray(int p,int N,int d) {
    int i,j;
    double ***mats = calloc(p, sizeof(double **));
    if(mats==NULL)
        {printf("An Error Has Occurred");
        exit(0);}
    for (i = 0; i < p; i++) {
        mats[i] = (double **) calloc(N,sizeof (double *));
        if(mats[i]==NULL)
           { printf("An Error Has Occurred");
             exit(0);
                    }

        for (j = 0; j < N; j++) {
            mats[i][j] = (double *) calloc(d, sizeof(double ));
            if(mats[i][j]==NULL)
                {printf("An Error Has Occurred");
                 exit(0);
                 }
        }
    }
    return mats;
}
void freeMemoryMat(double ***arr,int d, int size) {
    int i,j;
    for (i = 0; i < d; i++) {
        for (j = 0; j < size; ++j) {
            free(arr[i][j]);

        }
    }

    free(arr);
}

void GenParameters(double **S,double**Stag,double**P,double***matrix_arr,int l,int n)
{
        int maxI = 0, maxJ = 0,i,j;
        double theta = 0, t = 0, c = 0, s = 0,maxValue=0;
        for (i = 0; i < n; i++) {
            for (j = i; j < n; j++) {
                if ((fabs(S[i][j]) > fabs(maxValue)) && (i != j)) {
                    maxValue = S[i][j];
                    maxI = i;
                    maxJ = j;
                }
            }
        }
        theta = (S[maxJ][maxJ] - S[maxI][maxI]) / (2 * S[maxI][maxJ]);
        if (theta >= 0) {
            t = 1 / (theta+ sqrt(pow(theta, 2) + 1));
        } else {
            t = (-1 / (fabs(theta)+sqrt(pow(theta, 2) + 1)));
        }
        c = 1 / (sqrt(pow(t, 2) + 1));
        s = t * c;
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                if (i == j )
                {
                    if(i == maxI)
                        P[i][j] = c;
                    if(i==maxJ)
                        P[i][j]=c;
                    if(i!=maxI&&i!=maxJ)
                        P[i][j]=1;
                }
                else {
                    if (i == maxI && j == maxJ)
                        P[i][j] = s;
                    if (i == maxJ && j == maxI)
                        P[i][j] = -s;
                    if (i != j && !((i == maxI && j == maxJ) || (j == maxI && i == maxJ)))
                        P[i][j] = 0;
                }
            }
        }
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                matrix_arr[l][i][j]=P[i][j];
            }
        }
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                Stag[i][j] = S[i][j];
            }
        }
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                if (i != maxJ && i != maxI && j == maxI) {
                    Stag[i][j] = c * S[i][maxI] - s * S[i][maxJ];
                    Stag[j][i] = c * S[i][maxI] - s * S[i][maxJ];
                }
                if (i != maxJ && i != maxI && j == maxJ) {
                    Stag[i][j] = c * S[i][maxJ] + s * S[i][maxI];
                    Stag[j][i] = c * S[i][maxJ] + s * S[i][maxI];
                }
                if (i == maxI && j == maxI)
                    Stag[i][j] = pow(c, 2) * S[maxI][maxI] + pow(s, 2) * S[maxJ][maxJ] - 2 * c * s *maxValue;
                if (i == maxJ && j == maxJ)
                    Stag[i][j] = pow(s, 2) * S[maxI][maxI] + pow(c, 2) * S[maxJ][maxJ] + 2 * c * s * maxValue;
                if (i == maxJ && j ==maxI) {
                    Stag[i][j] = 0;
                    Stag[j][i] = 0;
                }
            }
        }
}
double*** GenJacobi(double **L,int n) {
    int i,j,l=0;
    double **P,**V,**Stag,**S,off,eps;
    double ***matrix_arr,***results;
    S = copyMat(L,n,n);
    P = (double **) initpointArray(n, n);
    V = (double **) initpointArray(n, n);
    Stag = (double **) initpointArray(n, n);
    matrix_arr = (double ***) initmatrixArray(100, n, n);
    results = (double ***) initmatrixArray(2, n, n);
    eps = epsilon;
    off = 100*eps;
    while (l < 100 && off > eps) {
        GenParameters(S,Stag,P,matrix_arr,l,n);
        off = offMat(S, Stag,n);
        for (i = 0; i < n; i++) {
            for (j = 0; j < n; j++) {
                S[i][j] = Stag[i][j];
            }
        }
        l++;
    }
    V = matrix_arr[0];
    for (i = 1; i < l; i++) {
        V = multiplyMat(V,matrix_arr[i],n);
    }
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            results[0][i][j]=V[i][j];
            results[1][i][j]=Stag[i][j];
        }
    }
    freeMemoryArray(V,n);
    freeMemoryArray(L,n);
    freeMemoryArray(S,n);
    freeMemoryArray(P,n);
    freeMemoryMat(matrix_arr,l,n);
    freeMemoryArray(Stag,n);
    return results;
}


void copy_array(double *p1, double *p2, int k)
{
    int j;
    for (j=0;j<k; j++) {
        p1[j] = p2[j];
    }
}
int GenEigengap(double **vectors,double **values,int n)
{
    int i,j;
    double temp=0.0,maxGap=0;
    int kIndex,minIndex;
    double *tempArr,*point;
    kIndex=0;
    tempArr = calloc(n, sizeof(double ));
    point = calloc(n,sizeof(double));
    if(tempArr==NULL || point==NULL)
       { printf("An Error Has Occurred");
        exit(0);}

    for (i= 0; i < n; i++) {
        point[i]=values[i][i];
    }
    for (i = 0; i < n-1; i++) {
        minIndex = i+1;
        for (j = i+1; j < n; j++)
        {
            if(point[j] < point[minIndex]) {
                minIndex=j;
            }
        }
        temp = point[i];
        point[i]=point[minIndex];
        point[minIndex]=temp;
        copy_array(tempArr,vectors[i],n);
        copy_array(vectors[i],vectors[minIndex],n);
        copy_array(vectors[minIndex],tempArr,n);
    }
    for (i= 0; i < n-1; i++) {
        if(maxGap<fabs(point[i]-point[i+1]))
        {
            kIndex=i;
            maxGap=fabs(point[i]-point[i+1]);
        }
    }
    free(tempArr);
    free(point);
    return kIndex+1;
}

double **Renormalize(double **P,int n,int k)
{
    int i,j;
    double **Ptag;
    double sum =0;
    Ptag = (double **)initpointArray(n,k);
    for (i = 0; i < n; i++) {
        for (j = 0; j < k; j++) {
            sum += pow(P[i][j],2);
        }
        for (j = 0; j < k; j++) {
            if(sum==0)
               Ptag[i][j]=0;
            else
               Ptag[i][j]=P[i][j]/ (pow(sum,0.5));
        }
        sum=0;
    }
    return Ptag;
}

void kMeans(double **points_arr,int N,int K)
{
    groupItem **groups;
    int equalsCounter,kmin,sizeGroup,cenUnchangedCounter,isChanged,iter,i,j,k,maxIter;
    groupItem *item,*tempItem;
    double **center_arr,*sum,minDist,distance;
    isChanged=1,iter=0;
    sum = calloc(K, sizeof(double ));
    if(sum==NULL)
       { printf("An Error Has Occurred");
                exit(0);
        }
    center_arr = (double **) initpointArray(K,K);
    groups = initGroups(K);
    for(i=0;i<K;i++)
    {
        for(j=0;j<K;j++)
        {
            center_arr[i][j]=points_arr[i][j];
        }
    }
    maxIter = MAX_ITER;
    while (isChanged && iter < maxIter) {
        cenUnchangedCounter = 0;
        /*separate to groups*/
        for (i = 0; i < N; i++)
        {
            minDist = -1; /* inf */
            kmin = -1;
            for (k = 0; k < K; k++) {
                distance = 0;
                /* compute distance */
                for (j = 0; j < K; j++) {
                    distance += pow((points_arr[i][j] - center_arr[k][j]),2);

                }
                if (minDist == -1 || distance < minDist) {
                    minDist = distance;
                    kmin = k;
                }
            }
            groups[kmin] = addToGroup(i, groups[kmin]);
        }
        /*update centroids*/
        for (k = 0; k < K; k++) {
            sum = calloc(K, sizeof(double ));
            if(sum==NULL)
               { printf("An Error Has Occurred");
                        exit(0);
               }
            item = groups[k];
            sizeGroup = 0;
            while (item != NULL) {
                i = item->data;
                for (j = 0; j < K; j++) {
                    sum[j] += points_arr[i][j];
                }
                sizeGroup++;
                tempItem = item;
                item = item->next;
                free(tempItem);
            }
            groups[k] = NULL; /* init groups to null for next iteration */
            equalsCounter = K;
            for (j = 0; j < K; j++) {
                if ((int) (center_arr[k][j] * 1000) != (int) (1000 * sum[j] / (double ) sizeGroup)) {
                    equalsCounter = 0;
                }
                if(sizeGroup!=0)
                    center_arr[k][j] = sum[j] / (double ) sizeGroup;
            }
            if (equalsCounter == K) {
                cenUnchangedCounter++;
            }
        }
        if (cenUnchangedCounter == K) {
            isChanged = 0;
        }
        iter++;
    }
    printMat(center_arr,K,K);
    /* free memories */
    free(sum);
    freeMemoryArray(center_arr, K);
    free(groups);
    free(item);
}


groupItem **initGroups(int K) {
    groupItem **groups = calloc(K, sizeof(groupItem *));
    if(groups==NULL)
        {printf("An Error Has Occurred");
                exit(0);
}
    return groups;
}


groupItem *addToGroup(int data, groupItem *firstItemGroup) {
    groupItem *item = (groupItem *) malloc(sizeof(groupItem));
    assert(item != NULL);
    item->data = data;
    item->next = firstItemGroup;
    return item;
}

