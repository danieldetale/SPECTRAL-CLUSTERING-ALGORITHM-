import sys
import numpy as np
import pandas as pd
from enum import Enum,auto
import mykmeanssp as km


class goal(Enum):
    spk = "spk"
    wam = "wam"
    ddg = "ddg"
    lnorm = "lnorm"
    jacobi = "jacobi"


def main():
    np.random.seed(0)

    if len(sys.argv) != 4:
        print("Invalid Input!")
        return 0

    K = int(sys.argv[1])
    g = (sys.argv[2])
    file_name = sys.argv[3]

    try:
        goal(g)
    except:
        print("Invalid Input!")
        return 0

    if K < 0:
        print("Invalid Input!")
        return 0
    try:
        df = pd.read_csv(file_name, header=None)
    except:
        print("An Error Has Occurred")
        return 0


    obs = df.to_numpy(dtype="float64")
    N = obs.shape[0]
    d = obs.shape[1]

    if N <= K:
        print("Invalid Input!")
        return 0
    indices = np.empty(K, dtype="int32")

    if goal[g] is not goal.spk:
        km.spk_means(K, N, d,g,indices.tolist(),obs.tolist())

    if K==0 and goal[g] is goal.spk:
        K = km.spk_means(K, N, d,g,indices.tolist(),obs.tolist())

    if goal[g] is goal.spk:
        indices = np.zeros(K, dtype="int32")
        newVals = (km.spk_means(K, N, d, g, indices.tolist(), obs.tolist()))
        newObs = np.zeros((N, K))
        y = 0
        for e in range(0, N):
            for q in range(0, K):
                newObs[e][q] = newVals[y]
                y += 1

        insert_in_index = 0
        cents = np.empty(shape=(K,K), dtype="float64")
        first_index = np.random.choice(newObs.shape[0], 1)[0]
        cents[0] = newObs[first_index]
        indices[insert_in_index] = first_index
        insert_in_index += 1
        distances = np.full(newObs.shape[0], np.inf, dtype="float64")

        for z in range(1, K):
            distances = np.minimum(distances, np.sum(np.power(cents[z-1] - newObs, 2), axis=1))
            probs = distances / np.sum(distances)# Calculate probability of each observation
            index = np.random.choice(newObs.shape[0], 1, p=probs)[0]  # Choose index randomly
            cents[z] = newObs[index]
            indices[insert_in_index] = index  # Update the array of indices
            insert_in_index += 1


        for p in range(0,K-1):
            print(indices[p], end=",")
        print(indices[K-1])
        km.spk_means(K, N, d,g,indices.tolist(),obs.tolist())

    return 0


main()