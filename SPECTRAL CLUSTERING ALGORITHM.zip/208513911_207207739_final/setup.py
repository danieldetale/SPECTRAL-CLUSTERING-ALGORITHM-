from setuptools import setup,find_packages,Extension

setup(
    name='mykmeanssp',
    version='0.1.0',
    author="Daniel & Lior",
    description="A functions that calculates k clusters using the kmeans algorithm",
    install_requires=['invoke', 'numpy'],
    packages=find_packages(),
    license='GPL-2',
    # See https://pypi.python.org/pypi?%3Aaction=list_classifiers
    classifiers=[
        'Natural Language :: English',
        'Programming Language :: Python :: 3 :: Only',
        'Programming Language :: Python :: Implementation :: CPython',
    ],
    ext_modules=[
        Extension(
            # the qualified name of the extension module to build
            'mykmeanssp',
            # the files to compile into our module relative to ``setup.py``
            ['spkmeansmodule.c', 'spkmeans.c'],
        ),
    ]
)
