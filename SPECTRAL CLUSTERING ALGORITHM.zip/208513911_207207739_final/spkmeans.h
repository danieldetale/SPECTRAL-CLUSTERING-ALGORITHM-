#include <math.h>
#define epsilon pow(10,-15);
#define MAX_ITER 300;

typedef struct lst {
    int data;
    struct lst *next;
} groupItem;

enum goal{spk=1,wam=2,ddg=3,lnorm=4,jacobi=5};

/*call Geneigengap to calculate k when its given as zero*/
int Get_means(double **points_arr,int n,int d);
double **initpointArray(int, int);
void printMat(double **A, int K, int d);
void freeMemoryArray(double **, int);


/*Generate wam*/
double** GenWeightMat(double **,int n,int d);
/*Generate ddg*/
double** GenDiagonalMat(double **,int n);

/*Multiply 2 matrix with nxn dim*/
double ** multiplyMat(double **A,double **B,int n);
double** GenLaplacian(double ** weightMat,double **diagonalMat,int n);

/*free 3d matrix*/
void freeMemoryMat(double ***arr,int d, int size);
/*init 3d matrix*/
double ***initmatrixArray(int p,int N, int d);

/*calculate the convergence for jacobi*/
double offMat(double **A,double **Atag,int n);
/*Transpose nxn matrix*/
double ** Transpose(double **P,int n);

/*Generate Jacobi*/
double*** GenJacobi(double **S,int n);
/*Generate the Parameters for GenJacobi function*/
void GenParameters(double **S,double**Stag,double**P,double***matrix_arr,int l,int n);

/*return copy of P with nxd dim*/
double ** copyMat(double **P,int n,int d);
/*copy array p1 to p2*/
void copy_array(double *p1, double *p2, int k);
/*calculate k when its given as zero*/
int GenEigengap(double **vectors,double **values,int n);
/*Form matrix T by normalize matrix U*/
double **Renormalize(double **P,int n,int k);

/*Kmeans functions*/
groupItem **initGroups(int K);
groupItem *addToGroup(int data, groupItem *firstItemGroup);
void kMeans(double **points_arr,int n,int K);
void PrintResults(double **cen, int K, int d);


/*Printing function for each state*/
void PrintWeightMat(double **points_arr,int n,int d);
void PrintDiagonalMat(double **points_arr,int n,int d);
void PrintLaplacian(double **points_arr,int n,int d);
void PrintJacobi(double **points_arr,int n,int d);
void PrintKmeans(double **points_arr,int n,int d,int k);

/*print kmeans as it use the random numbers from python*/
void PrintRandmeans(double **points_arr,int *center_arr,int n, int d ,int k);
/*return matrix T back to python for the kmeans++ algo*/
double *Get_T(double **points_arr,int n,int d,int k);
