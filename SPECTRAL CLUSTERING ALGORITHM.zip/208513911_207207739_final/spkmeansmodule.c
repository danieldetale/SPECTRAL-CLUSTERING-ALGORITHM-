#define PY_SSIZE_T_CLEAN  /* For all # variants of unit formats (s#, y#, etc.) use Py_ssize_t rather than int. */
#include <Python.h>       /* MUST include <Python.h>, this implies inclusion of the following standard headers:
                            <stdio.h>, <string.h>, <errno.h>, <limits.h>, <assert.h> and <stdlib.h> (if available). */
#include <stdio.h>
#include <stdlib.h>
#include "spkmeans.h"

double **initMatrix(int N, int d);
void freeAllMemories(double **observation, double **cen, groupItem **groups, int N, int K);
static PyObject *spk_means(int K, int N, int d,char*g,int *init_centroids, double **obs);
static PyObject *spk_means_capi(PyObject *self, PyObject *args);
static double **init_observations(PyObject *py_observation, int N, int d);
static int *init_index_centroids(PyObject *py_init_centroids, int K);

/*if k is zero calculate k and return it, otherwise print the matrix for each state*/
static PyObject *spk_means(int K, int N, int d,char*g, int *init_centroids, double **obs)
{
     int check,i;
     double *newobs;
     PyObject *l,*rev,*f;
     Py_ssize_t r;
     check=0,i=0;
     if (strcmp(g, "wam") == 0) {
        PrintWeightMat(obs,N,d);
     }
     if (strcmp(g, "ddg") == 0) {
        PrintDiagonalMat(obs,N,d);
     }
     if (strcmp(g, "lnorm") == 0) {
        PrintLaplacian(obs,N,d);
     }
     if (strcmp(g, "jacobi") == 0) {
        PrintJacobi(obs,N,d);
     }
     if (strcmp(g, "spk") == 0 && K==0 ){
        return Py_BuildValue("i",Get_means(obs,N,d));
     }
     if (strcmp(g, "spk") == 0 && K>0) {
        for(i=0;i<K;i++){
            if(init_centroids[i]!=0)
                check++;
        }

        if(check<=0)
        {
            newobs = Get_T(obs,N,d,K);
            l = PyList_New(K*N);
            for ( r = 0; r < (K*N); r++)
            {
                f = PyFloat_FromDouble(newobs[r]);
                PyList_SetItem(l, r, f);
            }
            rev =  Py_BuildValue("O",l);
            return rev;

        }
        else
        {
            PrintRandMeans(obs,init_centroids,N,d,K);
        }
     }


     return Py_BuildValue("i",0);

}


void freeAllMemories(double **observation, double **cen, groupItem **groups, int N, int K) {
    /* free memory for observation,cen  */
    freeMemoryArray(observation, N);
    freeMemoryArray(cen, K);
}



double **initMatrix(int N, int d) {
    /* alloc zero matrix of size NXd  */
    int i;
    double **mat = calloc(N, sizeof(double *));
    if (mat == NULL) {
        PyErr_SetString(PyExc_NameError, "allocation error in init matrix");
        return NULL;
    }
    for (i = 0; i < N; i++) {
        mat[i] = (double *) calloc(d, sizeof(double));
        if (mat[i] == NULL) {
            PyErr_SetString(PyExc_NameError, "allocation error in init matrix");
            return NULL;
        }
    }
    return mat;
}



static double **init_observations(PyObject *py_observation, int N, int d) {
/* convert Pyobject to matrix NXd of the observations */
    Py_ssize_t i, j;
    int n, obsize;
    PyObject *obs;
    PyObject *coordinate;
    double **observations;
    if (!PyList_Check(py_observation)) { /* check py_observation from python is indeed a list */
        PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
        return NULL;
    }
    n = PyList_Size(py_observation);
    if (n != N) {
        PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
        return NULL;
    }
    observations = initMatrix(N, d);
    if (observations == NULL) {
        return NULL;
    }
    for (i = 0; i < n; i++) {
        obs = PyList_GetItem(py_observation, i);
        if (!PyList_Check(obs)) {
            freeMemoryArray(observations,N);
            PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
            return NULL;
        }
        obsize = PyList_Size(obs);
        if (obsize != d) {
            freeMemoryArray(observations,N);
            PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
            return NULL;
        }
        for (j = 0; j < obsize; j++) {
            coordinate = PyList_GetItem(obs, j);
            if (!PyFloat_Check(coordinate)) {
                freeMemoryArray(observations,N);
                PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
                return NULL;
            }
            observations[i][j] = PyFloat_AsDouble(coordinate);
        }
    }
    return observations;
}

static int *init_index_centroids(PyObject *py_init_centroids, int K) {
/* convert Pyobject to Array of size K of the init centroids */

    Py_ssize_t i;
    int n;
    PyObject *item;
    int *init_centroids;
    if (!PyList_Check(py_init_centroids)) {
        PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
        return NULL;
    }
    n = PyList_Size(py_init_centroids);
    if (n != K) {
        PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
        return NULL;
    }
    init_centroids = (int *) calloc(n, sizeof(int));
    if (init_centroids == NULL) {
        PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
        return NULL;
    }
    for (i = 0; i < n; i++) {
        item = PyList_GetItem(py_init_centroids, i);
        if (!PyLong_Check(item)) {
            free(init_centroids);
            PyErr_SetString(PyExc_NameError, "An Error Has Occurred");
            return NULL;
        }
        init_centroids[i] = (int) PyLong_AsLong(item);
    }
    return init_centroids;
}



static PyObject *spk_means_capi(PyObject *self, PyObject *args) {
    /* input from arguments: K,N,d,MAX_ITER,py_init_centroids,py_observation
     * returns the PyObject results from kmeans */
    int K;
    int N;
    int d;
    char *g;
    PyObject *py_init_centroids;
    PyObject *py_observation;

    if (!PyArg_ParseTuple(args, "iiisOO", &K, &N, &d,&g, &py_init_centroids, &py_observation)) {
        return 0;
    }
    double **observation = init_observations(py_observation, N, d);
    int *init_centroids = init_index_centroids(py_init_centroids, K);
    if (observation == NULL || init_centroids == NULL) {
        freeMemoryArray(observation,N);
        free(init_centroids);
        return 0;
    }
    return spk_means(K, N, d,g, init_centroids, observation);
}
/*
 * This array tells Python what methods this module has.
 * We will use it in the next structure
 */
static PyMethodDef capiMethods[] = {
        {"spk_means",                   /* the Python method name that will be used */
                (PyCFunction) spk_means_capi, /* the C-function that implements the Python function and returns static PyObject*  */
                      METH_VARARGS,           /* flags indicating parametersaccepted for this function */
                         PyDoc_STR("spkmeans algorithm")}, /*  The docstring for the function */
        {NULL,  NULL, 0, NULL}     /* The last entry must be all NULL as shown to act as a
                                 sentinel. Python looks for this entry to know that all
                                 of the functions for the module have been defined. */
};


/* This initiates the module using the above definitions. */

static struct PyModuleDef moduledef = {
        PyModuleDef_HEAD_INIT,
        "mykmeanssp", /* name of module */
        NULL, /* module documentation, may be NULL */
        -1,  /* size of per-interpreter state of the module, or -1 if the module keeps state in global variables. */
        capiMethods /* the PyMethodDef array from before containing the methods of the extension */
};


/*
 * The PyModuleDef structure, in turn, must be passed to the interpreter in the module’s initialization function.
 * The initialization function must be named PyInit_name(), where name is the name of the module and should match
 * what we wrote in struct PyModuleDef.
 * This should be the only non-static item defined in the module file
 */


PyMODINIT_FUNC
PyInit_mykmeanssp(void) {
    PyObject *m;
    m = PyModule_Create(&moduledef);
    if (!m) {
        return NULL;
    }
    return m;
}
